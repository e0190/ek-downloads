// Firefox, which does three things its own way:
//
//  1. Certificates: it keeps its own list. `security.enterprise_roots.enabled`
//     makes it also trust the ones Windows and macOS trust (where the
//     installer put .ek's). Linux has no such switch, so there the .ek
//     certificate goes into each profile's own store with certutil.
//  2. Names: it searches for anything ending in a suffix it doesn't know, so
//     `news.ek` would be a web search. `browser.fixup.domainsuffixwhitelist.ek`
//     makes it an address.
//  3. Routing: it follows the system proxy settings by default, which the
//     installer already pointed at the helper, so nothing to do there.
//
// The settings go in each profile's user.js (read every time Firefox starts),
// between two marker lines so they can be taken out again. No policies, so
// Firefox never says it's "managed by your organization". The helper runs
// this when it starts, which also covers profiles made after install.
//
//   node server.mjs --firefox-off    take it all out again (the uninstallers do this)

import { readFileSync, writeFileSync, readdirSync, existsSync, statSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';
import { homedir } from 'node:os';

const START = '// ---- .ek (added by the .ek helper; removed when .ek is uninstalled) ----';
const END = '// ---- end .ek ----';
const PREFS = {
  'browser.fixup.domainsuffixwhitelist.ek': true,
  'security.enterprise_roots.enabled': true,
};
const CERT_NAME = '.ek local authority';

/** Every Firefox profile folder on this computer. */
function profiles() {
  const home = homedir();
  const roots = process.platform === 'win32'
    ? [join(process.env.APPDATA ?? join(home, 'AppData', 'Roaming'), 'Mozilla', 'Firefox')]
    : process.platform === 'darwin'
      ? [join(home, 'Library', 'Application Support', 'Firefox')]
      // Newer Firefox keeps profiles under ~/.config; older ones, and snaps, in .mozilla.
      : [join(process.env.XDG_CONFIG_HOME || join(home, '.config'), 'mozilla', 'firefox'),
         join(home, '.mozilla', 'firefox'), join(home, 'snap', 'firefox', 'common', '.mozilla', 'firefox'),
         join(home, '.var', 'app', 'org.mozilla.firefox', '.mozilla', 'firefox')];
  const found = [];
  for (const root of roots) {
    let ini;
    try { ini = readFileSync(join(root, 'profiles.ini'), 'utf8'); } catch { continue; }
    let relative = true;
    for (const line of ini.split(/\r?\n/)) {
      if (/^\[/.test(line)) relative = true;
      else if (/^IsRelative=0/.test(line)) relative = false;
      const path = line.match(/^Path=(.+)$/)?.[1];
      if (path) {
        const dir = relative ? join(root, path) : path;
        if (existsSync(dir) && statSync(dir).isDirectory() && !found.includes(dir)) found.push(dir);
      }
    }
  }
  return found;
}

const withoutBlock = (text) =>
  text.replace(new RegExp('\\r?\\n?' + escape(START) + '[\\s\\S]*?' + escape(END) + '\\r?\\n?'), '\n').replace(/^\n+/, '');
function escape(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

/** Put .ek's settings (and, on Linux, its certificate) into every Firefox profile. */
export function setUpFirefox(caPath) {
  const done = [];
  for (const dir of profiles()) {
    try {
      const file = join(dir, 'user.js');
      const old = existsSync(file) ? readFileSync(file, 'utf8') : '';
      const block = [START, ...Object.entries(PREFS).map(([k, v]) => `user_pref("${k}", ${JSON.stringify(v)});`), END].join('\n');
      const next = (withoutBlock(old).trimEnd() + '\n\n' + block + '\n').trimStart();
      if (next !== old) writeFileSync(file, next);
      if (process.platform === 'linux' && caPath) trustOnLinux(dir, caPath);
      done.push(dir);
    } catch (err) { console.log('firefox: ' + dir + ': ' + err.message); }
  }
  return done;
}

function trustOnLinux(dir, caPath) {
  if (!existsSync(join(dir, 'cert9.db'))) return; // Firefox makes it on first run; next helper start catches it
  try {
    const list = execFileSync('certutil', ['-d', 'sql:' + dir, '-L'], { encoding: 'utf8' });
    if (list.includes(CERT_NAME)) return;
    execFileSync('certutil', ['-d', 'sql:' + dir, '-A', '-t', 'C,,', '-n', CERT_NAME, '-i', caPath]);
  } catch { /* no certutil: the installer installs it; nothing else to do */ }
}

/** Take .ek back out of every Firefox profile. */
export function removeFromFirefox() {
  for (const dir of profiles()) {
    try {
      const file = join(dir, 'user.js');
      if (existsSync(file)) {
        const rest = withoutBlock(readFileSync(file, 'utf8'));
        writeFileSync(file, rest);
      }
      // Firefox copies user.js into prefs.js, so they'd stay set without this.
      // (Takes effect once Firefox is closed; it rewrites prefs.js on exit.)
      const prefsFile = join(dir, 'prefs.js');
      if (existsSync(prefsFile)) {
        const lines = readFileSync(prefsFile, 'utf8').split('\n');
        const kept = lines.filter((l) => !Object.keys(PREFS).some((k) => l.includes(`"${k}"`)));
        if (kept.length !== lines.length) writeFileSync(prefsFile, kept.join('\n'));
      }
      if (process.platform === 'linux') {
        try { execFileSync('certutil', ['-d', 'sql:' + dir, '-D', '-n', CERT_NAME], { stdio: 'ignore' }); } catch { /* not there */ }
      }
    } catch (err) { console.log('firefox: ' + dir + ': ' + err.message); }
  }
}
