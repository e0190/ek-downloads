// The .ek helper — makes ek names real in an ordinary browser's address bar.
//
// The browser is told (by a PAC file) to send anything ending in .ek here.
// This process answers those requests: for https://kettle.ek/ it serves the
// .ek app, which pulls kettle from the shared Turso database and renders it.
// Because it is a real navigation to a real host, the browser's own bar shows
// kettle.ek — no extension, no browser fork, no domain, nothing to pay for.
//
//   node server.mjs [port]         run the helper
//   node server.mjs --init-ca      create the local .ek authority and exit
//
// Everything except .ek keeps going straight to the internet — the PAC returns
// DIRECT for it, so those requests never even reach this process.

import { createServer } from 'node:http';
import { createServer as createHttpsServer } from 'node:https';
import { createSecureContext } from 'node:tls';
import { readFileSync, writeFileSync, existsSync, statSync, copyFileSync, renameSync, unlinkSync } from 'node:fs';
import { createHash, webcrypto } from 'node:crypto';
import { spawn } from 'node:child_process';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadAuthority, makeIssuer } from './certs.mjs';
import { makeNet } from './net.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));

// The authority lives next to the helper, which the installer puts in the
// user's own LocalAppData — readable by this user only.
if (process.argv.includes('--init-ca')) {
  loadAuthority(HERE);
  console.log(join(HERE, 'ca.crt'));
  process.exit(0);
}

const PORT = Number(process.argv[2] ?? process.env.EK_PORT ?? 7333);

/* One stray error must never take .ek down: Node ends the whole process on an
   error nothing caught, and with it every .ek page on this computer. Note it
   in helper.log (kept small) and keep serving. */
const LOG = join(HERE, 'helper.log');
function note(kind, err) {
  const line = new Date().toISOString() + ' ' + kind + ': ' + (err?.stack ?? String(err)) + '\n';
  try {
    if (existsSync(LOG) && statSync(LOG).size > 256 * 1024) renameSync(LOG, LOG + '.old');
    writeFileSync(LOG, line, { flag: 'a' });
  } catch { /* nowhere to write: still keep going */ }
}
process.on('uncaughtException', (err) => note('error', err));
process.on('unhandledRejection', (err) => note('rejected', err));

// The whole app is one file. Bundled next to this server when installed; read
// from the source tree in development.
const APP_PATH = [join(HERE, 'app.html'), join(HERE, '..', 'ek.html')]
  .find((p) => existsSync(p));
if (!APP_PATH) {
  console.error('Could not find app.html or ../ek.html to serve.');
  process.exit(1);
}
// Re-read whenever the file changes on disk, so updating the app never needs
// the helper restarted.
let appCache = { mtime: 0, html: '' };
function appHtml() {
  const mtime = statSync(APP_PATH).mtimeMs;
  if (mtime !== appCache.mtime) appCache = { mtime, html: readFileSync(APP_PATH, 'utf8') };
  return appCache.html;
}

const isEk = (host) => host === 'ek' || host.endsWith('.ek');

// What the browser fetches to learn the routing rule — directly, not proxied.
const PAC = `function FindProxyForURL(url, host) {
  if (host === "ek" || shExpMatch(host, "*.ek")) return "PROXY 127.0.0.1:${PORT}";
  return "DIRECT";
}
`;

/*
 * Who you are, across every .ek page.
 *
 * Each site is its own origin with its own storage, so a page on kettle.ek
 * can't see the identity kept on https://ek — and wouldn't know you own a site
 * or moderate the network. The app on https://ek tells the helper your id (the
 * public fingerprint only; the private key never leaves that page), and the
 * helper stamps it into every page it serves.
 */
const ME_PATH = join(HERE, 'me.txt');
let me = existsSync(ME_PATH) ? readFileSync(ME_PATH, 'utf8').trim() : '';
const ID_RE = /^ek1[0-9a-f]{12}$/;

function rememberMe(req, res) {
  // Only the app on https://ek itself may say who you are. A site's code runs
  // sandboxed with an opaque origin, so it arrives here as "null" and is refused.
  if (req.method !== 'POST' || req.headers.origin !== 'https://ek') {
    res.writeHead(403); res.end(); return;
  }
  let body = '';
  req.on('data', (c) => { body += c; if (body.length > 64) req.destroy(); });
  req.on('end', () => {
    const id = body.trim();
    if (!ID_RE.test(id)) { res.writeHead(400); res.end(); return; }
    if (id !== me) { me = id; writeFileSync(ME_PATH, id); }
    res.writeHead(204); res.end();
  });
}

/*
 * Light or dark, across every .ek page. The same problem as identity: each
 * site's storage is its own, so bright mode chosen on one page was forgotten
 * on the next. The app tells the helper when you switch, and the helper
 * stamps the choice into every page it serves.
 */
const THEME_PATH = join(HERE, 'theme.txt');
const THEMES = new Set(['light', 'dark']);
let theme = existsSync(THEME_PATH) ? readFileSync(THEME_PATH, 'utf8').trim() : '';

function rememberTheme(req, res, host) {
  // The app on any .ek host may set it. A site's own code runs sandboxed with
  // an opaque origin, so it arrives as "null" and is refused.
  if (req.method !== 'POST' || req.headers.origin !== 'https://' + host) {
    res.writeHead(403); res.end(); return;
  }
  let body = '';
  req.on('data', (c) => { body += c; if (body.length > 16) req.destroy(); });
  req.on('end', () => {
    const mode = body.trim();
    if (!THEMES.has(mode)) { res.writeHead(400); res.end(); return; }
    if (mode !== theme) { theme = mode; writeFileSync(THEME_PATH, mode); }
    res.writeHead(204); res.end();
  });
}

/* ------------------------------------------------------------- updates
   The helper keeps .ek up to date by itself. tools/release.mjs leaves a
   signed note in the database for each new version; this reads it, and if
   it's newer than the app on disk, downloads the new ek.html, checks it is
   exactly the file the note names (sha-256), and swaps it in. Nothing is
   trusted that isn't signed with the release key — the database can be
   written by anyone who digs the publish key out of the app. */
const RELEASE_KEY = 'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEpz2Cwyp5jneMUDHwYMCvMev9mYOk9G4rKHyGIyBdrqvN+AXNCLuNVFDcENMc8dLK1nBUte8pdpVn/DgmMjG/lw==';
const APP_URL = 'https://eknetwork.vercel.app/ek.html';
// Only an installed helper updates itself; in development it serves ../ek.html.
const CAN_UPDATE = APP_PATH === join(HERE, 'app.html');

/* The newest release note: from eknetwork.vercel.app/api/release, which keeps
   working whatever happens to the database's keys; failing that, from the
   database with the app's read-only key. Either way only a note signed with
   the release key counts. */
const RELEASE_API = 'https://eknetwork.vercel.app/api/release';
async function releaseRow() {
  try {
    const res = await fetch(RELEASE_API, { cache: 'no-store', signal: AbortSignal.timeout(15_000) });
    if (res.ok) return await res.json();
  } catch { /* try the database */ }
  const app = appHtml();
  const url = app.match(/url:\s*'([^']+)'/)?.[1];
  const token = app.match(/readToken:\s*'([^']+)'/)?.[1];
  if (!url || !token) return null;
  const res = await fetch(url.replace(/^libsql:\/\//, 'https://') + '/v2/pipeline', {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer ' + token },
    body: JSON.stringify({ requests: [
      { type: 'execute', stmt: { sql: 'SELECT version, notes, sha, get, at, signature FROM releases ORDER BY at DESC LIMIT 1' } },
      { type: 'close' },
    ] }),
  });
  const row = (await res.json()).results?.[0]?.response?.result?.rows?.[0];
  if (!row) return null;
  const [version, notes, sha, get, at, signature] = row.map((c) => c?.value);
  return { version, notes, sha, get, at, signature };
}

async function latestRelease() {
  const row = await releaseRow();
  if (!row || !row.signature) return null;
  const note = { version: String(row.version), notes: String(row.notes), sha: String(row.sha), get: Number(row.get), at: Number(row.at) };
  const key = await webcrypto.subtle.importKey('spki', Buffer.from(RELEASE_KEY, 'base64'),
    { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
  const ok = await webcrypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key,
    Buffer.from(String(row.signature), 'base64'), new TextEncoder().encode(JSON.stringify(note)));
  return ok ? note : null;
}

let updating = null;
/** True once the app on disk is the newest released version. */
function updateApp() {
  updating ??= (async () => {
    try {
      if (!CAN_UPDATE) return true;
      const note = await latestRelease();
      const have = appHtml().match(/const BUILD = '([^']*)';/)?.[1] ?? '';
      // The app is current; its list of helper files may still be ahead of us.
      if (!note || !(note.version > have)) { await updateHelper(); return true; }
      const body = Buffer.from(await (await fetch(APP_URL, { cache: 'no-store' })).arrayBuffer());
      if (createHash('sha256').update(body).digest('hex') !== note.sha) return false;
      // Written beside it and then moved into place, so a half-written file
      // is never served. The one it replaces is kept, just in case.
      const next = join(HERE, 'app.next.html');
      writeFileSync(next, body);
      try { copyFileSync(APP_PATH, join(HERE, 'app.previous.html')); } catch { /* first time */ }
      renameSync(next, APP_PATH);
      console.log('.ek updated to ' + note.version);
      await updateHelper();
      return true;
    } catch (err) {
      console.log('update check failed: ' + err.message);
      return false;
    } finally {
      updating = null;
    }
  })();
  return updating;
}
/* The helper's own files. The app lists the sha-256 of each one it was
   released with (HELPER_FILES), and the app itself was just checked against
   the signed release, so a file matching its hash is the released one. Any
   that differ are downloaded, checked, swapped in together, and the helper
   restarts itself through ek-helper.exe. Nothing changes unless every file
   checks out. */
const HELPER_URL = 'https://eknetwork.vercel.app/helper/';
async function updateHelper() {
  if (!CAN_UPDATE) return;
  const listed = appHtml().match(/const HELPER_FILES = (\{[^}]*\});/)?.[1];
  if (!listed) return;
  let want;
  try { want = JSON.parse(listed); } catch { return; }
  const sha = (buf) => createHash('sha256').update(buf).digest('hex');
  const got = [];
  for (const [name, hash] of Object.entries(want)) {
    if (!/^[a-z0-9-]+\.(mjs|ps1)$/.test(name)) continue;
    let have = '';
    try { have = sha(readFileSync(join(HERE, name))); } catch { /* new file */ }
    if (have === hash) continue;
    const body = Buffer.from(await (await fetch(HELPER_URL + name, { cache: 'no-store' })).arrayBuffer());
    if (sha(body) !== hash) { console.log('helper update: ' + name + " didn't match, nothing changed"); return; }
    got.push([name, body]);
  }
  if (!got.length) return;
  for (const [name, body] of got) writeFileSync(join(HERE, name + '.next'), body);
  for (const [name] of got) renameSync(join(HERE, name + '.next'), join(HERE, name));
  console.log('helper updated: ' + got.map(([n]) => n).join(', '));
  restart();
}

/** Start again on the new files: a fresh helper (ek-helper.exe, or launchd on a Mac), then this one goes. */
function restart() {
  // On a Mac, launchd (KeepAlive) starts a fresh helper as soon as this one exits.
  if (process.platform === 'darwin') { server.close(); setTimeout(() => process.exit(0), 300); return; }
  const exe = join(HERE, 'ek-helper.exe');
  if (!existsSync(exe)) return;
  server.close();
  spawn(exe, [], { detached: true, stdio: 'ignore', cwd: HERE }).unref();
  setTimeout(() => process.exit(0), 300);
}

setTimeout(updateApp, 10_000);
setInterval(updateApp, 30 * 60 * 1000);

/* The account the installer made (account.mjs) left its key here. The app on
   https://ek collects it once, the first time it opens, and it's deleted:
   after that the key lives in the browser like any other .ek key. Only
   https://ek may ask — a site's sandboxed code arrives with origin "null". */
const PENDING = join(HERE, 'pending-key.json');
function firstKey(req, res) {
  if (req.method !== 'POST' || req.headers.origin !== 'https://ek') { res.writeHead(403); res.end(); return; }
  req.resume();
  if (!existsSync(PENDING)) { res.writeHead(204); res.end(); return; }
  const body = readFileSync(PENDING, 'utf8');
  try { unlinkSync(PENDING); } catch { /* next time */ }
  res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
  res.end(body);
}

/* Your key, for every .ek page. Each .ek address is its own origin with its
   own storage, so on its own https://mail.ek or https://kettle.ek can't see
   the key https://ek holds. The helper keeps the one copy they all share.
   Only .ek's own pages can reach it — a site's sandboxed code arrives with
   origin "null" — and only https://ek and https://mail.ek (where you sign in)
   may change it. `at` says which copy is newest (see syncKey in the app). */
const KEY_PATH = join(HERE, 'key.json');
const readBody = (req, max) => new Promise((resolve) => {
  let body = '';
  req.on('data', (c) => { body += c; if (body.length > max) req.destroy(); });
  req.on('end', () => resolve(body));
  req.on('error', () => resolve(''));
});
async function sharedKey(req, res, host, path) {
  const origin = req.headers.origin;
  if (req.method !== 'POST' || origin !== 'https://' + host) { res.writeHead(403); res.end(); return; }
  if (path === '/__ek/key') {
    req.resume();
    if (!existsSync(KEY_PATH)) { res.writeHead(204); res.end(); return; }
    res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    res.end(readFileSync(KEY_PATH, 'utf8'));
    return;
  }
  // /__ek/key/set
  if (host !== 'ek' && host !== 'mail.ek') { req.resume(); res.writeHead(403); res.end(); return; }
  let rec;
  try { rec = JSON.parse(await readBody(req, 8192)); } catch { rec = null; }
  if (!rec || typeof rec.pub !== 'string' || !rec.jwk || rec.jwk.kty !== 'EC' || !rec.jwk.d || typeof rec.at !== 'number') {
    res.writeHead(400); res.end(); return;
  }
  writeFileSync(KEY_PATH, JSON.stringify({ jwk: rec.jwk, pub: rec.pub, at: rec.at }));
  res.writeHead(204); res.end();
}

/* The network, kept once here for every .ek page (see net.mjs). Any .ek
   page may read it (it's public anyway); a site's sandboxed code arrives with
   origin "null" and can't. */
const net = makeNet({ dir: HERE, appHtml });
setTimeout(() => net.sync(), 5_000);
setInterval(() => net.sync(), 10 * 60 * 1000);
async function serveNet(req, res, host, path) {
  if (req.method !== 'POST' || req.headers.origin !== 'https://' + host) { res.writeHead(403); res.end(); return; }
  req.resume();
  const body = await net.get(path === '/__ek/net/sync');
  res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
  res.end(body);
}

/** One of a site's other files (a picture, a sound…), by its SHA-256. */
async function serveBlob(req, res, host, path) {
  if (req.method !== 'POST' || req.headers.origin !== 'https://' + host) { res.writeHead(403); res.end(); return; }
  req.resume();
  let data = null;
  try { data = await net.blob(path.slice('/__ek/blob/'.length)); } catch { /* offline */ }
  if (!data) { res.writeHead(404); res.end(); return; }
  res.writeHead(200, { 'content-type': 'application/octet-stream', 'cache-control': 'no-store' });
  res.end(data);
}

/* Something on the bar was pressed and the page is about to change: the
   next .ek page opened within a few seconds keeps the bar down (the app reads
   <meta name="ek-bar">). Needed because that page is often another address,
   which can't see anything this one remembers. */
let barUntil = 0;
function holdBar(req, res, host) {
  if (req.method !== 'POST' || req.headers.origin !== 'https://' + host) { res.writeHead(403); res.end(); return; }
  req.resume();
  barUntil = Date.now() + 4000;
  res.writeHead(204); res.end();
}

/** The app asking for the update now, from its banner. */
async function updateNow(req, res, host) {
  if (req.method !== 'POST' || req.headers.origin !== 'https://' + host) { res.writeHead(403); res.end(); return; }
  req.resume();
  const ok = await updateApp();
  res.writeHead(ok ? 204 : 502); res.end();
}

/** Serve the app. The app's own router reads the host to pick the site. */
function serveApp(req, res) {
  res.writeHead(200, {
    'content-type': 'text/html; charset=utf-8',
    'cache-control': 'no-store',
  });
  if (req.method === 'HEAD') { res.end(); return; }
  let html = appHtml();
  const stamps = [];
  if (me) stamps.push(`<meta name="ek-me" content="${me}">`);
  // Only the page itself takes the mark, not an icon or other request on the way.
  const dest = req.headers['sec-fetch-dest'];
  if (Date.now() < barUntil && (!dest || dest === 'document')) {
    stamps.push('<meta name="ek-bar" content="1">');
    barUntil = 0;
  }
  if (THEMES.has(theme)) {
    stamps.push(`<meta name="ek-theme" content="${theme}">`);
    // On the root element too, so the page never flashes the other theme
    // while the app's script is still loading.
    html = html.replace(/<html\b/, `<html data-theme="${theme}"`);
  }
  res.end(stamps.length ? html.replace('<head>', '<head>\n' + stamps.join('\n')) : html);
}

/* ------------------------------------------------------------------ https */
const ca = loadAuthority(HERE);
const issue = makeIssuer(ca);
const contexts = new Map();

// Never listens on a port of its own: CONNECT tunnels are handed to it below.
const secure = createHttpsServer({
  SNICallback(servername, done) {
    const host = String(servername || '').toLowerCase();
    if (!isEk(host)) return done(new Error('not a .ek host'));
    if (!contexts.has(host)) contexts.set(host, createSecureContext(issue(host)));
    done(null, contexts.get(host));
  },
}, (req, res) => {
  const host = String(req.headers.host ?? '').split(':')[0].toLowerCase();
  if (!isEk(host)) { res.writeHead(421); res.end(); return; }
  const path = req.url.split('?')[0];
  if (host === 'ek' && path === '/__ek/me') { rememberMe(req, res); return; }
  if (path === '/__ek/theme') { rememberTheme(req, res, host); return; }
  if (path === '/__ek/update') { updateNow(req, res, host); return; }
  if (path === '/__ek/bar') { holdBar(req, res, host); return; }
  if (host === 'ek' && path === '/__ek/first-key') { firstKey(req, res); return; }
  if (path === '/__ek/key' || path === '/__ek/key/set') { sharedKey(req, res, host, path); return; }
  if (path === '/__ek/net' || path === '/__ek/net/sync') { serveNet(req, res, host, path); return; }
  if (path.startsWith('/__ek/blob/')) { serveBlob(req, res, host, path); return; }
  serveApp(req, res);
});
secure.on('tlsClientError', () => {});

/* ------------------------------------------------------------ the proxy */
/** The host a plain-http request is really for, proxied or direct. */
function targetHost(req) {
  try { return new URL(req.url).hostname.toLowerCase(); } catch { /* origin-form */ }
  return String(req.headers.host ?? '').split(':')[0].toLowerCase();
}

const server = createServer((req, res) => {
  const host = targetHost(req);

  if (host === '127.0.0.1' || host === 'localhost') {
    res.writeHead(200, { 'content-type': 'application/x-ns-proxy-autoconfig' });
    res.end(req.method === 'HEAD' ? undefined : PAC);
    return;
  }

  if (!isEk(host)) {
    res.writeHead(421, { 'content-type': 'text/plain' });
    res.end('The .ek helper only serves .ek addresses.');
    return;
  }

  // Plain http for a .ek name: send it to the secure version, which is the
  // only one where the app's crypto works.
  let path = '/';
  try { const u = new URL(req.url, 'http://' + host); path = u.pathname + u.search; } catch { /* keep / */ }
  res.writeHead(301, { location: 'https://' + host + path });
  res.end();
});

// https://name.ek arrives as "CONNECT name.ek:443". Accept the tunnel and hand
// the raw socket to the https server, which does TLS with a certificate for
// exactly that name.
server.on('connect', (req, socket, head) => {
  const host = String(req.url).split(':')[0].toLowerCase();
  if (!isEk(host)) {
    socket.end('HTTP/1.1 403 Forbidden\r\n\r\n');
    return;
  }
  socket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
  if (head && head.length) socket.unshift(head);
  secure.emit('connection', socket);
});

server.on('clientError', (err, socket) => {
  if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
});

// Bind to loopback only — this is a personal helper, never a public server.
// Just after an update the old helper may still be letting go of the port.
let tries = 0;
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE' && ++tries < 40) { setTimeout(() => server.listen(PORT, '127.0.0.1'), 250); return; }
  console.error(err.message);
  process.exit(1);
});
server.listen(PORT, '127.0.0.1', () => {
  console.log('.ek helper on 127.0.0.1:' + PORT + ' — serving ' + APP_PATH);
});
