#!/bin/bash
# Removes .ek from this Mac. Anything you published stays in the .ek network.
PORT=7333
DIR="$HOME/Library/Application Support/ek"
AGENT="$HOME/Library/LaunchAgents/net.ek.helper.plist"
PAC="http://127.0.0.1:$PORT/ek.pac"

[ "${EK_CI:-}" = 1 ] || osascript -e 'display dialog "Remove .ek from this Mac?\n\nSites stop opening in your browser. Anything you published stays in the .ek network." buttons {"Cancel", "Remove"} default button "Remove" with title "Remove .ek"' >/dev/null 2>&1 || exit 0

launchctl bootout "gui/$(id -u)" "$AGENT" 2>/dev/null
rm -f "$AGENT"

# The routing (only where it's still ours) and the certificate: one password prompt.
SCRIPT="security delete-certificate -c '.ek local authority' /Library/Keychains/System.keychain || true"
while IFS= read -r svc; do
  if networksetup -getautoproxyurl "$svc" | grep -q "URL: $PAC\$"; then
    SCRIPT="$SCRIPT; networksetup -setautoproxyurl '$svc' ''; networksetup -setautoproxystate '$svc' off"
  fi
done < <(networksetup -listallnetworkservices | tail -n +2 | grep -v '^\*')
if [ "${EK_CI:-}" = 1 ]; then sudo bash -c "$SCRIPT"; else osascript -e "do shell script \"$SCRIPT\" with administrator privileges" >/dev/null 2>&1; fi

# Firefox: its .ek settings (see firefox.mjs)
"$DIR/runtime/bin/node" "$DIR/server.mjs" --firefox-off 2>/dev/null

rm -rf "$DIR"
echo ".ek is removed."
