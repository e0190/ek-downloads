// Make an .ek account from the installer.
//
//   node account.mjs status              {"on":true|false}
//   node account.mjs check <username>    {"ok":true} or {"error":"…"}
//   node account.mjs create <username>   password on stdin; {"ok":true,"username":…}
//
// Creates a new key, locks a copy with the password, and registers the
// account, exactly as the app does (accounts in app.html — keep the two in
// step: accountBody, the lock, the fingerprint). The key is then left in
// pending-key.json for the helper to hand to https://ek the first time it
// opens (server.mjs, /__ek/first-key), after which that file is gone.

import { writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { webcrypto as crypto } from 'node:crypto';

const HERE = dirname(fileURLToPath(import.meta.url));
const out = (o) => { process.stdout.write(JSON.stringify(o) + '\n'); };

// Accounts are made through the network's write server, which holds the
// accounts database's key (site/api/write.mjs) and checks the signature.
const WRITE_API = 'https://eknetwork.vercel.app/api/write';
async function api(op, body) {
  const res = await fetch(WRITE_API, { method: 'POST', headers: { 'content-type': 'application/json', connection: 'close' },
    body: JSON.stringify({ ...body, op }) });
  const out = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(out.error || 'The network said ' + res.status + '.');
  return out;
}

const USER_RE = /^[a-z0-9_]{3,20}$/;
const RESERVED = new Set(['admin', 'ek', 'eknet', 'eknetwork', 'root', 'support', 'help', 'system',
  'moderator', 'mod', 'official', 'null', 'undefined', 'anonymous', 'everyone', 'you', 'me',
  'mail', 'postmaster', 'abuse', 'security', 'noreply', 'no_reply']);
// Everyone starts at name@mail.ek; the app lets them move it to a site they own.
const MAIL = 'mail';
const PASS_MIN = 10, LOCK_ITERS = 600000;
const ALG = { name: 'ECDSA', namedCurve: 'P-256' }, SIGN = { name: 'ECDSA', hash: 'SHA-256' };
const b64 = (buf) => Buffer.from(buf).toString('base64');

const accountBody = (a) => JSON.stringify({
  username: String(a.username), domain: String(a.domain), owner_key: String(a.owner_key),
  locked_key: String(a.locked_key), salt: String(a.salt), iters: Number(a.iters), created: Number(a.created),
});

function problemWith(u) {
  if (!USER_RE.test(u)) return '3 to 20 characters: lowercase letters, numbers and _';
  if (RESERVED.has(u)) return 'That name is kept for the network';
  return '';
}

async function taken(u) {
  const { rows } = await api('accounts', { username: u, domain: MAIL });
  return rows.length > 0;
}

async function create(u, password) {

  const pair = await crypto.subtle.generateKey(ALG, true, ['sign', 'verify']);
  const jwk = await crypto.subtle.exportKey('jwk', pair.privateKey);
  const pub = b64(await crypto.subtle.exportKey('spki', pair.publicKey));
  const digest = await crypto.subtle.digest('SHA-256', Buffer.from(pub, 'base64'));
  const id = 'ek1' + Buffer.from(digest).toString('hex').slice(0, 12);

  const salt = b64(crypto.getRandomValues(new Uint8Array(16)));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveKey']);
  const lock = await crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', iterations: LOCK_ITERS, salt: Buffer.from(salt, 'base64') },
    base, { name: 'AES-GCM', length: 256 }, false, ['encrypt']);
  const sealed = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, lock, new TextEncoder().encode(JSON.stringify(jwk)));
  const rec = { username: u, domain: MAIL, owner_id: id, owner_key: pub, locked_key: b64(iv) + '.' + b64(sealed), salt, iters: LOCK_ITERS, created: Date.now() };
  rec.signature = b64(await crypto.subtle.sign(SIGN, pair.privateKey, new TextEncoder().encode(accountBody(rec))));

  await api('account-create', { rec });
  // For the helper to hand to https://ek once.
  writeFileSync(join(HERE, 'pending-key.json'), JSON.stringify({ jwk, pub, id, username: u, address: u + '@mail.ek' }));
  return rec;
}

const readStdin = () => new Promise((resolve) => {
  let s = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (c) => { s += c; });
  process.stdin.on('end', () => resolve(s.replace(/\r?\n$/, '')));
});

try {
  const [cmd, name = ''] = process.argv.slice(2);
  const u = name.trim().toLowerCase().replace(/^@/, '');
  if (cmd === 'status') out({ on: true });
  else if (cmd === 'check') {
    const bad = problemWith(u);
    out(bad ? { error: bad } : (await taken(u)) ? { error: u + '@mail.ek is taken. Try another name.' } : { ok: true });
  } else if (cmd === 'create') {
    const bad = problemWith(u);
    if (bad) out({ error: bad });
    else {
      const password = await readStdin();
      if (password.length < PASS_MIN) out({ error: 'Use at least ' + PASS_MIN + ' characters for the password.' });
      else { await create(u, password); out({ ok: true, username: u, address: u + '@mail.ek' }); }
    }
  } else out({ error: 'Unknown command.' });
} catch (err) {
  out({ error: err.message });
}
