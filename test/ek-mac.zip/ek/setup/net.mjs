// One copy of the network for every .ek page (server.mjs, /__ek/net).
//
// Under the helper every .ek address is its own origin, so on its own each one
// would keep its own copy of the whole network in the browser, and the first
// visit to a new address would wait for a download before it could open
// anything. The helper keeps the one copy instead, in network.json, already
// unpacked, and hands it to whichever page asks.
//
// Nothing here is trusted: the rows are passed on as the database has them,
// and every page checks each site's signature itself (verifySite in the app).

import { readFileSync, writeFileSync, renameSync, mkdirSync, readdirSync, statSync, unlinkSync, utimesSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { inflateRawSync } from 'node:zlib';
import { Worker } from 'node:worker_threads';
import { join } from 'node:path';

const COLS = 'name, owner_key, owner_id, description, files, signature, size, created, updated, visibility';

export function makeNet({ dir, appHtml }) {
  const FILE = join(dir, 'network.json');
  let state = { sites: {}, blocked: [], dead: [], at: 0 };
  try {
    const saved = JSON.parse(readFileSync(FILE, 'utf8'));
    if (saved && saved.sites) state = saved;
  } catch { /* first run */ }
  let json = null;                 // state, serialised once per change

  /** Run statements against the network with the app's read-only token. */
  async function run(statements) {
    const app = appHtml();
    const block = app.match(/const NETWORK = \{[\s\S]*?\};/)?.[0] ?? '';
    const url = block.match(/url:\s*'([^']+)'/)?.[1];
    const token = block.match(/readToken:\s*'([^']+)'/)?.[1];
    if (!url || !token) throw new Error('no network in the app');
    const res = await fetch(url.replace(/^libsql:\/\//, 'https://') + '/v2/pipeline', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + token },
      body: JSON.stringify({ requests: [...statements.map(([sql, ...args]) => ({ type: 'execute',
        stmt: { sql, args: args.map((v) => ({ type: 'text', value: String(v) })) } })), { type: 'close' }] }),
      signal: AbortSignal.timeout(20_000),
    });
    if (!res.ok) throw new Error('the network said ' + res.status);
    const body = await res.json();
    const bad = (body.results ?? []).find((r) => r.type === 'error');
    if (bad) throw new Error(bad.error?.message ?? 'query failed');
    return body.results.filter((r) => r.response?.type === 'execute').map((r) => {
      const cols = r.response.result.cols.map((c) => c.name);
      return r.response.result.rows.map((row) => Object.fromEntries(row.map((cell, i) => [cols[i],
        !cell || cell.type === 'null' ? null
          : cell.type === 'integer' ? Number(cell.value)
          : cell.type === 'blob' ? Buffer.from(cell.base64, 'base64')
          : cell.value])));
    });
  }

  /* ekz is slow and synchronous, so it runs off the main thread, where it
     can't hold up pages being served. Its code comes out of the app itself
     (between the ekz markers), so it always matches the rows it reads. */
  function unpackEkz(bytes, version) {
    const app = appHtml();
    const a = app.indexOf('/* [ekz] */'), b = app.indexOf('/* [/ekz] */');
    if (a < 0 || b < 0) return Promise.reject(new Error('no ekz in the app'));
    const code = app.slice(a, b);
    return new Promise((resolve, reject) => {
      const w = new Worker(`
        const { parentPort, workerData } = require('node:worker_threads');
        const lib = new Function(workerData.code + '\\nreturn ekzLib(EKZ_DICT);')();
        const read = workerData.version === 2 ? lib.unpack2 : (lib.unpack ?? lib.expandSite);
        parentPort.postMessage(read(workerData.bytes));
      `, { eval: true, workerData: { code, bytes, version } });
      w.once('message', resolve);
      w.once('error', reject);
      w.once('exit', (c) => { if (c) reject(new Error('ekz worker stopped')); });
    });
  }

  async function unpack(stored) {
    if (typeof stored === 'string') return JSON.parse(stored);
    if (stored[0] === 0xFF) {
      if (stored[1] !== 1 && stored[1] !== 2) throw new Error('made by a newer .ek');
      return unpackEkz(new Uint8Array(stored.subarray(2)), stored[1]);
    }
    return JSON.parse(inflateRawSync(stored).toString('utf8'));
  }

  let syncing = null;
  /** Bring the copy up to date with the network. Only changed sites download. */
  function sync() {
    syncing ??= (async () => {
      try {
        const [meta, blocked, dead] = await run([
          ['SELECT name, owner_key, updated FROM sites ORDER BY updated DESC LIMIT 2000'],
          ['SELECT name FROM blocked'],
          ['SELECT name, owner_key, at FROM deleted'],
        ]);
        const sites = { ...state.sites };
        const stale = meta.filter((m) => {
          const known = sites[m.name];
          return !(known && known.owner_key === m.owner_key && known.updated >= m.updated);
        }).map((m) => m.name);
        for (let i = 0; i < stale.length; i += 50) {
          const part = stale.slice(i, i + 50);
          const [rows] = await run([[`SELECT ${COLS} FROM sites WHERE name IN (${part.map(() => '?').join(',')})`, ...part]]);
          for (const row of rows) {
            try { sites[row.name] = { ...row, files: await unpack(row.files) }; }
            catch { /* unreadable here: leave it out, the app can still fetch it */ }
          }
        }
        // Gone from the network (deleted or taken down): gone from the copy.
        if (meta.length < 2000) {
          const present = new Set(meta.map((m) => m.name));
          for (const name of Object.keys(sites)) if (!present.has(name)) delete sites[name];
        }
        state = { sites, blocked: blocked.map((r) => r.name), dead, at: Date.now() };
        json = null;
        const tmp = FILE + '.next';
        writeFileSync(tmp, JSON.stringify(state));
        renameSync(tmp, FILE);
        return true;
      } catch (err) {
        console.log('network copy: ' + err.message);
        return false;
      } finally {
        syncing = null;
      }
    })();
    return syncing;
  }

  /* Sites' other files (pictures, sound…), fetched the first time a page asks
     and kept in blobs/ for next time, up to BLOB_CACHE; the least recently
     used go first. Checked against their name (a SHA-256) before they're kept. */
  const BLOBS = join(dir, 'blobs');
  const BLOB_CACHE = 200 * 1024 * 1024;
  function trimBlobs() {
    let files;
    try { files = readdirSync(BLOBS).map((f) => { const st = statSync(join(BLOBS, f)); return { f, size: st.size, at: st.mtimeMs }; }); }
    catch { return; }
    let total = files.reduce((n, x) => n + x.size, 0);
    for (const x of files.sort((a, b) => a.at - b.at)) {
      if (total <= BLOB_CACHE) break;
      try { unlinkSync(join(BLOBS, x.f)); total -= x.size; } catch { /* in use */ }
    }
  }
  async function blob(hash) {
    if (!/^[0-9a-f]{64}$/.test(hash)) return null;
    const file = join(BLOBS, hash);
    if (existsSync(file)) {
      try { const now = new Date(); utimesSync(file, now, now); } catch { /* fine */ }
      return readFileSync(file);
    }
    const [rows] = await run([['SELECT data FROM blobs WHERE hash = ?', hash]]);
    const data = rows[0]?.data;
    if (!data || createHash('sha256').update(data).digest('hex') !== hash) return null;
    mkdirSync(BLOBS, { recursive: true });
    writeFileSync(file, data);
    trimBlobs();
    return data;
  }

  return {
    sync,
    blob,
    /** The copy as JSON. fresh: check with the network first. */
    async get(fresh) {
      if (fresh || !state.at) await sync();
      // Kept reasonably current between visits without anyone waiting on it.
      else if (Date.now() - state.at > 60_000) sync();
      json ??= JSON.stringify(state);
      return json;
    },
  };
}
