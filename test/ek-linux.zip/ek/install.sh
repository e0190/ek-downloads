#!/bin/bash
# .ek setup for Linux. Run it from the folder it came in:   ./install.sh
#
# 1. Copies the helper into ~/.local/share/ek
# 2. Downloads Node.js from nodejs.org for it, checked against nodejs.org's own checksums
# 3. Trusts this computer's .ek-only certificate in Chrome/Brave/Edge's certificate store
# 4. Points .ek addresses at the helper (GNOME or KDE proxy settings)
# 5. Starts the helper now and every time you log in
# Nothing here needs sudo, except installing certutil if it's missing.
set -euo pipefail

PORT=7333
SRC="$(cd "$(dirname "$0")" && pwd)/setup"
DIR="${XDG_DATA_HOME:-$HOME/.local/share}/ek"
UNIT="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user/ek-helper.service"
AUTOSTART="${XDG_CONFIG_HOME:-$HOME/.config}/autostart/ek-helper.desktop"
PAC="http://127.0.0.1:$PORT/ek.pac"
NODE_VERSION="v24.13.0"

say() { printf '\n\033[1m%s\033[0m\n' "$1"; }
fail() { printf '\n\033[31m%s\033[0m\n' "$1"; exit 1; }
trap 'fail "Something went wrong. Run ./install.sh again to finish."' ERR

say ".ek setup"

# --- 1. files
say "1/5  Copying .ek"
systemctl --user stop ek-helper 2>/dev/null || true
pkill -f "$DIR/server.mjs" 2>/dev/null || true
mkdir -p "$DIR"
cp -R "$SRC/." "$DIR/"

# --- 2. node
say "2/5  Getting Node.js $NODE_VERSION"
case "$(uname -m)" in x86_64) ARCH=x64 ;; aarch64|arm64) ARCH=arm64 ;; *) fail "This computer's processor isn't supported." ;; esac
if [ "$("$DIR/runtime/bin/node" --version 2>/dev/null || true)" != "$NODE_VERSION" ]; then
  TMP="$(mktemp -d)"
  NAME="node-$NODE_VERSION-linux-$ARCH"
  curl -fsSL "https://nodejs.org/dist/$NODE_VERSION/$NAME.tar.xz" -o "$TMP/node.txz"
  curl -fsSL "https://nodejs.org/dist/$NODE_VERSION/SHASUMS256.txt" -o "$TMP/sums.txt"
  WANT="$(grep " $NAME.tar.xz\$" "$TMP/sums.txt" | cut -d' ' -f1)"
  HAVE="$(sha256sum "$TMP/node.txz" | cut -d' ' -f1)"
  [ -n "$WANT" ] && [ "$WANT" = "$HAVE" ] || fail "Node.js didn't download correctly. Check your internet and try again."
  rm -rf "$DIR/runtime"; mkdir -p "$DIR/runtime/bin"
  tar -xJf "$TMP/node.txz" -C "$TMP" "$NAME/bin/node"
  mv "$TMP/$NAME/bin/node" "$DIR/runtime/bin/node"
  rm -rf "$TMP"
fi
NODE="$DIR/runtime/bin/node"
CA="$("$NODE" "$DIR/server.mjs" --init-ca)"

# --- 3. certificate: Chrome, Brave and Edge on Linux read ~/.pki/nssdb
say "3/5  Trusting the .ek certificate"
if ! command -v certutil >/dev/null; then
  echo "This needs certutil. Installing it (your password may be asked for)..."
  if command -v apt-get >/dev/null; then sudo apt-get install -y libnss3-tools
  elif command -v dnf >/dev/null; then sudo dnf install -y nss-tools
  elif command -v pacman >/dev/null; then sudo pacman -S --noconfirm nss
  elif command -v zypper >/dev/null; then sudo zypper install -y mozilla-nss-tools
  else fail "Install certutil (the NSS tools package for your system), then run ./install.sh again."; fi
fi
trust_in() {
  mkdir -p "$1"
  [ -f "$1/cert9.db" ] || certutil -d "sql:$1" -N --empty-password
  certutil -d "sql:$1" -D -n ".ek local authority" 2>/dev/null || true
  certutil -d "sql:$1" -A -t "C,," -n ".ek local authority" -i "$CA"
}
trust_in "$HOME/.pki/nssdb"
# Snap and Flatpak browsers each keep their own store.
for app in "$HOME"/snap/{chromium,brave,microsoft-edge}/current "$HOME"/.var/app/{com.google.Chrome,com.brave.Browser,org.chromium.Chromium,com.microsoft.Edge}; do
  [ -d "$app" ] && trust_in "$app/.pki/nssdb"
done

# --- 4. routing
say "4/5  Sending .ek addresses to the helper"
ROUTED=""
if command -v gsettings >/dev/null && gsettings list-keys org.gnome.system.proxy >/dev/null 2>&1; then
  MODE="$(gsettings get org.gnome.system.proxy mode)"
  if [ "$MODE" = "'manual'" ]; then
    echo "You already use a proxy, so .ek left your settings alone. Set this as your proxy's automatic configuration URL: $PAC"
  else
    gsettings set org.gnome.system.proxy autoconfig-url "$PAC"
    gsettings set org.gnome.system.proxy mode 'auto'
    ROUTED=gnome
  fi
fi
for kw in kwriteconfig6 kwriteconfig5; do
  if command -v "$kw" >/dev/null; then
    "$kw" --file kioslaverc --group 'Proxy Settings' --key 'Proxy Config Script' "$PAC"
    "$kw" --file kioslaverc --group 'Proxy Settings' --key ProxyType 2
    ROUTED="${ROUTED:+$ROUTED+}kde"; break
  fi
done
[ -n "$ROUTED" ] || echo "Couldn't find GNOME or KDE settings. Start your browser with: --proxy-pac-url=$PAC"

# --- 5. start, and start at login (systemd restarts it if it ever stops)
say "5/5  Starting .ek"
if systemctl --user show-environment >/dev/null 2>&1; then
  mkdir -p "$(dirname "$UNIT")"
  cat > "$UNIT" <<UNIT
[Unit]
Description=.ek helper
After=network-online.target

[Service]
ExecStart="$NODE" "$DIR/server.mjs"
WorkingDirectory=$DIR
Restart=always
RestartSec=1
StandardOutput=append:$DIR/helper.log
StandardError=append:$DIR/helper.log

[Install]
WantedBy=default.target
UNIT
  systemctl --user daemon-reload
  systemctl --user enable --now ek-helper >/dev/null 2>&1
  systemctl --user restart ek-helper
else
  # No systemd for this user: start at login the desktop way, and start it now.
  mkdir -p "$(dirname "$AUTOSTART")"
  printf '[Desktop Entry]\nType=Application\nName=.ek helper\nExec=sh -c '\''cd "%s" && exec "%s" server.mjs >> helper.log 2>&1'\''\nNoDisplay=true\n' "$DIR" "$NODE" > "$AUTOSTART"
  (cd "$DIR" && nohup "$NODE" server.mjs >> helper.log 2>&1 &)
fi
for _ in $(seq 50); do curl -fs "$PAC" >/dev/null 2>&1 && break; sleep 0.1; done
curl -fs "$PAC" >/dev/null || fail "The helper didn't start. See $DIR/helper.log"

trap - ERR
say ".ek is installed."
echo "Restart Chrome, Brave or Edge (close every window), then go to https://ek"
echo "(Installed a browser after .ek? Open it once, then run ./install.sh again so it trusts .ek too.)"
echo "To remove .ek later, run: $DIR/uninstall.sh"
