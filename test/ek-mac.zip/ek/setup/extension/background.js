// The .ek connector. Its real job is one rule in rules.json: when the browser
// turns "kettle.ek" into a search (it doesn't know .ek is a website), send it
// to https://kettle.ek/ instead. The .ek helper on this computer does the rest.
//
// This file only adds two conveniences, neither of which needs a permission:
// typing "ek" then a space in the address bar, and the toolbar button.

// One to three labels, so subdomains work too: kettle, blog.kettle.
const NAME_RE = /^(?:[a-z0-9](?:[a-z0-9-]{0,30}[a-z0-9])?\.){0,2}[a-z0-9](?:[a-z0-9-]{0,30}[a-z0-9])?$/;
const siteUrl = (name) => `https://${name}.ek/`;
const clean = (s) => String(s).trim().toLowerCase()
  .replace(/^ek:(?:\/\/)?/, '').replace(/\/+$/, '').replace(/\.ek$/, '');

chrome.action.onClicked.addListener(() => chrome.tabs.create({ url: 'https://ek/' }));

chrome.omnibox.setDefaultSuggestion({ description: 'Open a <match>.ek</match> site' });

chrome.omnibox.onInputChanged.addListener((input, suggest) => {
  const name = clean(input);
  suggest(NAME_RE.test(name) ? [{ content: name, description: `Open <match>${name}.ek</match>` }] : []);
});

chrome.omnibox.onInputEntered.addListener((input, disposition) => {
  const name = clean(input);
  const url = NAME_RE.test(name) ? siteUrl(name) : 'https://ek/';
  if (disposition === 'newForegroundTab') chrome.tabs.create({ url });
  else if (disposition === 'newBackgroundTab') chrome.tabs.create({ url, active: false });
  else chrome.tabs.update({ url });
});
