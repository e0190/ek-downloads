#!/bin/bash
# .ek setup for Mac. Double-click this file (the first time: right-click > Open).
#
# 1. Copies the helper into ~/Library/Application Support/ek
# 2. Downloads Node.js from nodejs.org for it, checked against nodejs.org's own checksums
# 3. Trusts this Mac's .ek-only certificate and points .ek addresses at the helper
#    (macOS asks for your password once, for this step)
# 4. Starts the helper now and every time you log in
set -euo pipefail

PORT=7333
SRC="$(cd "$(dirname "$0")" && pwd)/setup"
DIR="$HOME/Library/Application Support/ek"
AGENT="$HOME/Library/LaunchAgents/net.ek.helper.plist"
NODE_VERSION="v24.13.0"

say() { printf '\n\033[1m%s\033[0m\n' "$1"; }
fail() { printf '\n\033[31m%s\033[0m\n' "$1"; osascript -e "display alert \".ek setup\" message \"$1\"" >/dev/null 2>&1 || true; exit 1; }
trap 'fail "Something went wrong. Run setup again to finish."' ERR

clear 2>/dev/null || true
say ".ek setup"

# --- 1. files
say "1/4  Copying .ek"
launchctl bootout "gui/$(id -u)" "$AGENT" 2>/dev/null || true
mkdir -p "$DIR"
cp -R "$SRC/." "$DIR/"
xattr -dr com.apple.quarantine "$DIR" 2>/dev/null || true

# --- 2. node
say "2/4  Getting Node.js $NODE_VERSION"
case "$(uname -m)" in arm64) ARCH=arm64 ;; x86_64) ARCH=x64 ;; *) fail "This Mac's processor isn't supported." ;; esac
if [ "$("$DIR/runtime/bin/node" --version 2>/dev/null || true)" != "$NODE_VERSION" ]; then
  TMP="$(mktemp -d)"
  NAME="node-$NODE_VERSION-darwin-$ARCH"
  curl -fsSL "https://nodejs.org/dist/$NODE_VERSION/$NAME.tar.gz" -o "$TMP/node.tgz"
  curl -fsSL "https://nodejs.org/dist/$NODE_VERSION/SHASUMS256.txt" -o "$TMP/sums.txt"
  WANT="$(grep " $NAME.tar.gz\$" "$TMP/sums.txt" | cut -d' ' -f1)"
  HAVE="$(shasum -a 256 "$TMP/node.tgz" | cut -d' ' -f1)"
  [ -n "$WANT" ] && [ "$WANT" = "$HAVE" ] || fail "Node.js didn't download correctly. Check your internet and try again."
  rm -rf "$DIR/runtime"; mkdir -p "$DIR/runtime/bin"
  tar -xzf "$TMP/node.tgz" -C "$TMP" "$NAME/bin/node"
  mv "$TMP/$NAME/bin/node" "$DIR/runtime/bin/node"
  rm -rf "$TMP"
fi
NODE="$DIR/runtime/bin/node"
CA="$("$NODE" "$DIR/server.mjs" --init-ca)"

# --- 3. certificate + routing (one password prompt)
say "3/4  Trusting the .ek certificate (macOS will ask for your password)"
PAC="http://127.0.0.1:$PORT/ek.pac"
SCRIPT="security add-trusted-cert -d -r trustRoot -k /Library/Keychains/System.keychain '$CA'"
while IFS= read -r svc; do
  SCRIPT="$SCRIPT; networksetup -setautoproxyurl '$svc' '$PAC'; networksetup -setautoproxystate '$svc' on"
done < <(networksetup -listallnetworkservices | tail -n +2 | grep -v '^\*')
if [ "${EK_CI:-}" = 1 ]; then sudo bash -c "$SCRIPT"; else
osascript -e "do shell script \"$SCRIPT\" with administrator privileges with prompt \".ek needs to trust its own certificate and send .ek addresses to the helper.\"" >/dev/null \
  || fail "Setup needs your password for this step. Run it again and enter it when asked."; fi

# --- 4. start, and start at login (launchd also restarts it if it ever stops)
say "4/4  Starting .ek"
mkdir -p "$(dirname "$AGENT")"
cat > "$AGENT" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>net.ek.helper</string>
  <key>ProgramArguments</key><array><string>$NODE</string><string>$DIR/server.mjs</string></array>
  <key>WorkingDirectory</key><string>$DIR</string>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$DIR/helper.log</string>
  <key>StandardErrorPath</key><string>$DIR/helper.log</string>
</dict></plist>
PLIST
launchctl bootstrap "gui/$(id -u)" "$AGENT"
for _ in $(seq 50); do curl -fs "$PAC" >/dev/null 2>&1 && break; sleep 0.1; done

trap - ERR
say ".ek is installed."
echo "Restart Chrome, Brave or Edge (Cmd+Q, then open it again), then go to https://ek"
echo "To remove .ek later, double-click \"Uninstall .ek.command\" in $DIR"
osascript -e 'display notification "Restart your browser, then go to https://ek" with title ".ek is installed"' >/dev/null 2>&1 || true
