#!/bin/bash
# Removes .ek from this computer. Anything you published stays in the .ek network.
PORT=7333
DIR="${XDG_DATA_HOME:-$HOME/.local/share}/ek"
UNIT="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user/ek-helper.service"
AUTOSTART="${XDG_CONFIG_HOME:-$HOME/.config}/autostart/ek-helper.desktop"
PAC="http://127.0.0.1:$PORT/ek.pac"

if [ "${1:-}" != "-y" ]; then
  read -r -p "Remove .ek from this computer? Sites stop opening in your browser. [y/N] " a
  case "$a" in y|Y|yes) ;; *) exit 0 ;; esac
fi

systemctl --user disable --now ek-helper 2>/dev/null
rm -f "$UNIT" "$AUTOSTART"
systemctl --user daemon-reload 2>/dev/null
pkill -f "$DIR/server.mjs" 2>/dev/null

# The routing, only where it's still ours
if command -v gsettings >/dev/null && [ "$(gsettings get org.gnome.system.proxy autoconfig-url 2>/dev/null)" = "'$PAC'" ]; then
  gsettings set org.gnome.system.proxy mode 'none'
  gsettings reset org.gnome.system.proxy autoconfig-url
fi
for kw in kwriteconfig6 kwriteconfig5; do
  if command -v "$kw" >/dev/null && grep -q "$PAC" "${XDG_CONFIG_HOME:-$HOME/.config}/kioslaverc" 2>/dev/null; then
    "$kw" --file kioslaverc --group 'Proxy Settings' --key ProxyType 0
    "$kw" --file kioslaverc --group 'Proxy Settings' --key 'Proxy Config Script' --delete
    break
  fi
done

command -v certutil >/dev/null && certutil -d "sql:$HOME/.pki/nssdb" -D -n ".ek local authority" 2>/dev/null
rm -rf "$DIR"
echo ".ek is removed."
