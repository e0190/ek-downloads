// Certificates for .ek, so sites are served over https.
//
// Browsers only give pages their crypto (which .ek's signatures depend on) in
// a secure context, and a plain http://kettle.ek is not one. So the helper
// serves https://kettle.ek, with a certificate signed by a small certificate
// authority created on this machine at install.
//
// That authority is name-constrained to .ek: it can only vouch for `ek` and
// `*.ek`. Browsers enforce that, so even if its key were stolen it could not
// be used to impersonate any real website. The key never leaves this PC.

import forge from 'node-forge';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';

const { pki, asn1, md } = forge;

const serial = () => '01' + forge.util.bytesToHex(forge.random.getBytesSync(15));

/** NameConstraints: permitted dNSName "ek" (which covers ek and every x.ek). */
function onlyEk() {
  const U = asn1.Class.UNIVERSAL, C = asn1.Class.CONTEXT_SPECIFIC;
  const dns = asn1.create(C, 2, false, 'ek');
  const subtree = asn1.create(U, asn1.Type.SEQUENCE, true, [dns]);
  const permitted = asn1.create(C, 0, true, [subtree]);
  const nc = asn1.create(U, asn1.Type.SEQUENCE, true, [permitted]);
  return { id: '2.5.29.30', critical: true, value: asn1.toDer(nc).getBytes() };
}

/** Make the local authority. Returns PEM strings; the installer trusts ca.crt. */
export function createAuthority() {
  const keys = pki.rsa.generateKeyPair(2048);
  const cert = pki.createCertificate();
  cert.publicKey = keys.publicKey;
  cert.serialNumber = serial();
  cert.validity.notBefore = new Date(Date.now() - 86400000);
  cert.validity.notAfter = new Date(Date.now() + 10 * 365 * 86400000);
  const name = [
    { name: 'commonName', value: '.ek local authority' },
    { name: 'organizationName', value: '.ek (this computer only)' },
  ];
  cert.setSubject(name);
  cert.setIssuer(name);
  cert.setExtensions([
    { name: 'basicConstraints', cA: true, pathLenConstraint: 0, critical: true },
    { name: 'keyUsage', keyCertSign: true, cRLSign: true, critical: true },
    { name: 'subjectKeyIdentifier' },
    onlyEk(),
  ]);
  cert.sign(keys.privateKey, md.sha256.create());
  return { cert: pki.certificateToPem(cert), key: pki.privateKeyToPem(keys.privateKey) };
}

/** Load the authority from dir, creating it the first time. */
export function loadAuthority(dir) {
  const certPath = join(dir, 'ca.crt');
  const keyPath = join(dir, 'ca.key');
  if (!existsSync(certPath) || !existsSync(keyPath)) {
    mkdirSync(dir, { recursive: true });
    const made = createAuthority();
    writeFileSync(certPath, made.cert);
    writeFileSync(keyPath, made.key);
  }
  return {
    cert: pki.certificateFromPem(readFileSync(certPath, 'utf8')),
    key: pki.privateKeyFromPem(readFileSync(keyPath, 'utf8')),
    certPem: readFileSync(certPath, 'utf8'),
  };
}

/**
 * Issues certificates for individual .ek hosts. One key pair is shared by all
 * of them (generating RSA keys in JavaScript is slow); only the signature is
 * per host, and results are cached.
 */
export function makeIssuer(ca) {
  const leafKeys = pki.rsa.generateKeyPair(2048);
  const keyPem = pki.privateKeyToPem(leafKeys.privateKey);
  const cache = new Map();

  return function issue(host) {
    if (cache.has(host)) return cache.get(host);
    const cert = pki.createCertificate();
    cert.publicKey = leafKeys.publicKey;
    cert.serialNumber = serial();
    cert.validity.notBefore = new Date(Date.now() - 86400000);
    // Under 398 days, the most browsers accept for a leaf certificate.
    cert.validity.notAfter = new Date(Date.now() + 390 * 86400000);
    cert.setSubject([{ name: 'commonName', value: host }]);
    cert.setIssuer(ca.cert.subject.attributes);
    cert.setExtensions([
      { name: 'basicConstraints', cA: false },
      { name: 'keyUsage', digitalSignature: true, keyEncipherment: true, critical: true },
      { name: 'extKeyUsage', serverAuth: true },
      { name: 'subjectAltName', altNames: [{ type: 2, value: host }] },
    ]);
    cert.sign(ca.key, md.sha256.create());
    const out = { cert: pki.certificateToPem(cert) + ca.certPem, key: keyPem };
    cache.set(host, out);
    return out;
  };
}
